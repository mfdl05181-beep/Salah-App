package com.salah.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
 private val bg=Color.rgb(8,6,11); private val pink=Color.rgb(244,125,187); private val white=Color.WHITE
 private var tasbeeh=0
 private fun txt(s:String,n:Float=17f,c:Int=white)=TextView(this).apply{text=s;textSize=n;setTextColor(c);gravity=Gravity.CENTER;setPadding(12,14,12,14)}
 private fun button(s:String,fn:()->Unit)=Button(this).apply{text=s;setTextColor(white);setBackgroundColor(Color.rgb(54,25,45));setOnClickListener{fn()}}
 private fun layout(title:String):LinearLayout=LinearLayout(this).apply{orientation=1;gravity=Gravity.CENTER_HORIZONTAL;setBackgroundColor(bg);setPadding(16,12,16,18);addView(txt("☾  صلاة  ☽",28f,pink));addView(txt(title,22f));addView(txt("تحت إشراف م/محمد فضل",14f,pink))}
 private fun show(v:LinearLayout){setContentView(ScrollView(this).apply{addView(v)})}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);home()}
 private fun home(){
  val v=layout("رفيقك الإسلامي اليومي")
  v.addView(txt("السلام عليكم ورحمة الله وبركاته",18f,pink))
  v.addView(txt("🕋  مواقيت الصلاة",20f,pink))
  v.addView(txt("الفجر  •  الظهر  •  العصر\nالمغرب  •  العشاء  •  الشروق",17f))
  val c=Calendar.getInstance();v.addView(txt("الوقت الحالي  %02d:%02d".format(c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE)),20f))
  v.addView(txt("لإظهار مواقيت دقيقة: اختر المدينة وطريقة الحساب من الإعدادات.",13f))
  v.addView(button("🕋 مواقيت الصلاة"){prayer()})
  v.addView(button("📖 القرآن الكريم"){quran()})
  v.addView(button("🤲 الأذكار والسبحة"){azkar()})
  v.addView(button("🧭 بوصلة القبلة"){qibla()})
  v.addView(button("🔔 الأذان والتنبيهات"){settings("الأذان والتنبيهات","إعدادات التنبيه لكل صلاة\nميزة الأذان في الخلفية تحتاج استكمال خدمة Android واختبار الإذن.")})
  v.addView(button("📅 التقويم الهجري"){settings("التقويم الهجري","التقويم الهجري يحتاج مكتبة تقويم مع خيار تعديل التاريخ.")})
  v.addView(button("⚙️ الإعدادات والخصوصية"){settings("الإعدادات","المدينة: اختيار يدوي\nطريقة الحساب: اختيار من الطرق المعتمدة\nالعصر: حنفي / شافعي\nالخصوصية: لا يتم إرسال بيانات شخصية في هذه النسخة.")})
  v.addView(txt("صلاة • عبادتك أقرب",16f,pink));show(v)
 }
 private fun page(title:String,body:String){val v=layout(title);v.addView(txt(body,17f));v.addView(button("⌂ الرئيسية"){home()});show(v)}
 private fun prayer(){page("مواقيت الصلاة","مواقيت اليوم\n\nالفجر —\nالشروق —\nالظهر —\nالعصر —\nالمغرب —\nالعشاء —\n\nلم يتم حساب الوقت: يلزم إدخال موقع المدينة وربط محرك مواقيت الصلاة.") }
 private fun quran(){val v=layout("القرآن الكريم");v.addView(txt("فهرس السور",18f,pink));listOf("الفاتحة","البقرة","آل عمران","النساء","المائدة","الأنعام","الأعراف","الأنفال","التوبة","يونس","هود","يوسف").forEach{s->v.addView(button("سورة $s"){page(s,"أضف نصًا قرآنيًا موثوقًا ومراجعًا لعرض السورة كاملة هنا.")})};v.addView(button("الرئيسية"){home()});show(v)}
 private fun azkar(){val v=layout("الأذكار والسبحة");v.addView(txt("أذكار الصباح والمساء",19f,pink));listOf("سبحان الله","الحمد لله","لا إله إلا الله","الله أكبر","أستغفر الله").forEach{v.addView(txt(it))};v.addView(txt("عدد التسبيح: $tasbeeh",24f,pink));v.addView(button("＋ تسبيحة"){tasbeeh++;azkar()});v.addView(button("إعادة العداد"){tasbeeh=0;azkar()});v.addView(button("الرئيسية"){home()});show(v)}
 private fun qibla(){page("بوصلة القبلة","🧭\n\nاتجاه القبلة والمسافة إلى مكة\n\nهذه شاشة تأسيسية؛ يلزم تفعيل الموقع وحساسات الاتجاه ومعايرتها لإظهار اتجاه حقيقي.") }
 private fun settings(t:String,b:String){page(t,b)}
}
